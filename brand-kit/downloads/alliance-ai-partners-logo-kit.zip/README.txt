Alliance AI Partners logo kit (2026-11-02)

lockups/ and marks/: SVG for screens and print, PNG at 2x for documents.
Use full-color-light on Daylight or white, full-color-dark on Partner Navy, mono-white on photographs,
flat-* where gradients cannot print (embroidery, screen print), mono-black for one-ink work.
Clear space: 0.287 x the mark's height on every side. Do not recolour, stretch, outline or rebuild the logo.
Colours: Alliance Blue #1B56FF, Ribbon Cyan #00D5FF, Partner Navy #121B2A, Daylight #F4F7FB.
